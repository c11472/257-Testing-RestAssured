
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseOptions;

public class ReqResGet_W {
	public static void main(String args[]) throws InterruptedException {
        RestAssured.baseURI = "https://reqres.in";
        
        String Endp ="/api/users" ;

        String apiKey = "reqres-free-v1";
        
        // token

        Response response = RestAssured
                .given()
                .auth().oauth2(apiKey)
               // .header("Authorization","" + apiKey)   // sending API key as Bearer token
                .when()
                .get(Endp)
                .then()
                .extract()
                .response();
        
        // response documentation methods
        
        int statusCode=response.statusCode();
        String statusLine=response.statusLine();
        int statusCode1=response.getStatusCode();
        String statusLine1=response.getStatusLine();
        
        String bodyData = response.getBody().asPrettyString();
        System.out.println(bodyData);

        System.out.println(statusCode + " " + statusLine + " " + statusCode1 + " " +statusLine1);

		}

}

