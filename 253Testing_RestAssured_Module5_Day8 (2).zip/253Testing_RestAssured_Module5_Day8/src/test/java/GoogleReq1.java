import static io.restassured.RestAssured.*;

public class GoogleReq1 {
	public static void main(String[] args) {
	//	import static io.restassured.RestAssured.*;

		given()
		    .relaxedHTTPSValidation()
		.when()
		    .get("https://www.google.com")
		.then()
		    .statusCode(200);

	}

}
