package TestNG_RestAssured_APITest;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import junit.framework.Assert;

public class TC_001_Git_GetReq {
	
   
    
	// step-2  ----- Bearer Token  
    String token = "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";
    
    String ep1= "/users/c11472";
    
    // Expected Data code 
    int expCode = 200;
    
    String Line1 = "HTTP/1.1 200 OK";
   
  @Test(priority=1)
  public void getRequestValidation() {
	    RestAssured.baseURI = "https://api.github.com";
	    
    	// step-2  ----- Bearer Token  
       // String token = "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";
	    
	    
		int code = RestAssured
		        .given().relaxedHTTPSValidation()
		        .header("Authorization", "Bearer " + token)
		        .get(ep1).statusCode(); // 200
		
		Assert.assertEquals(expCode, code);
		
		
		System.out.println(code);
		
  }
  @Test(priority=2)
  public void StatusMessage_Get() {
	  
	 Response responseTest= RestAssured.get(ep1);
	 
	 String Result_Body=responseTest.body().asString();
	 System.out.println("**************************************");
	 
	 System.out.println(Result_Body);	  
  }
  
  @Test(priority=3)
  public void StatusLine_Check() {
	  
	  Response responseTest= RestAssured.get(ep1);
	 String rest1= responseTest.statusLine();
	 
	 System.out.println(rest1);

	 
	 Assert.assertEquals(rest1, Line1);
	 
	// System.out.println(rest1);  
  }
}



