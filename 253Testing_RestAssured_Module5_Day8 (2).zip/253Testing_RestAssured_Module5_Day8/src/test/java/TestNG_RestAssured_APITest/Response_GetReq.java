package TestNG_RestAssured_APITest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class Response_GetReq {
	public static void main(String[] args) {
		
		// validation components ----- StatusCode , StatusMessage , ResponseBody
		String token = "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";
	    
	    String ep1= "/users/c11472";
	    
	    RestAssured.baseURI = "https://api.github.com";
	    
	    
	    Response res = RestAssured.get(ep1);
	    
	    
	    
	    String StatusLine = res.getStatusLine();
	    
	   
	    
	    System.out.println(StatusLine);
	    String  opt=res.asString();
	    System.out.println("******************************");
	    
	    System.out.println(opt);
	    
	    
	   String bodyData = res.getBody().asString();
	   
	   System.out.println(bodyData);
	    

	    
		
	}

}
