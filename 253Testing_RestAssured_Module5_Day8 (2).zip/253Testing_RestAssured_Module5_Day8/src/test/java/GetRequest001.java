import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ResponseOptions;

public class GetRequest001 {
	public static void main(String args[]) throws InterruptedException {
		// given -- all the input details
		// when -- submit api
		// then -- validate response

		// RestAssured.baseURI = "https://reqres.in/api/users/2";
		// Then - verify the status code

		// Set the base URI for the API

		//RestAssured.baseURI = "https://reqres.in/";
		
		
		RestAssured.baseURI = "https://api.apis.guru/v2";

		
		//RestAssured.baseURI="";

		// Send a GET request to the endpoint
	//	Response response = RestAssured.get("/api/user/2");
		
		Response response = RestAssured.get("/providers.json");
		
		
		

		/*RestAssured.put()
		RestAssured.patch()
		RestAssured.delete()*/
		
		
	   // System.out.println(response.getStatusCode());
	    
	    int StatusCode = response.getStatusCode();
	    System.out.println(StatusCode); // assertion - TestNG assertion
	    
	    
	   String StatusMessage= response.getStatusLine();
	   System.out.println(StatusMessage); // assertion - TestNG
	
	   
	 // ResponseBody StatusBody = response.getBody();
	   
	  // System.out.println(StatusBody1);
	   
	   
	   ResponseOptions opt=(ResponseOptions) response.body();
	   
	   System.out.println(opt);		
/*
		Thread.sleep(1500);

		System.out.println(response.getStatusCode()); // 200

		Thread.sleep(1500);

		System.out.println(response.getBody().asString()); // res body

		String contentType = response.getContentType();
		System.out.println(contentType);

		String SessionId = response.getSessionId();
		System.out.println(SessionId); // null

		System.out.println(response.getTime());

		String exp_statusLine = "200 OK";

		String Act_StatusLine = response.getStatusLine();

		System.out.println(Act_StatusLine); // HTTP/1.1 200 OK

		if (Act_StatusLine.contains(exp_statusLine)) {
			System.out.println("Valid Response code");

		} else {
			System.out.println("Invalid Responce code");
		}
*/
	}

}
