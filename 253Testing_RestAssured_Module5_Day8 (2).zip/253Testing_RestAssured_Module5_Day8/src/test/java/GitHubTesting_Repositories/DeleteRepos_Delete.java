package GitHubTesting_Repositories;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteRepos_Delete {
	public static void main(String[] args) {
		
	

	RestAssured.baseURI = "https://api.github.com";
    
    // Delete
    // DELETE /repos/{owner}/{repo}


    String token = "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";

    String body = """
        {
          "name": "restassured-demo-repo1",
          "description": "Created using GitHub REST API",
          "private": false
        }
        """;
    
    
    Response response = given()
            .auth().oauth2(token)
            .header("Accept", "application/vnd.github+json")
            .body(body)
            .delete("/user/repos/repoName"); // Notice the endpoint 

    System.out.println("Status Code: " + response.getStatusCode());
    }

}
