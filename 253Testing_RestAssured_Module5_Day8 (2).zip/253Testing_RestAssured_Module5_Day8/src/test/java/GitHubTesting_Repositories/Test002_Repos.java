package GitHubTesting_Repositories;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Test002_Repos {

    public static void main(String[] args) {
// prerequisites
    	
    	    //step-1 ---- BaseURI
    	    RestAssured.baseURI = "https://api.github.com";
    	    
    	// step-2  ----- Bearer Token  
        String token = "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";
        
        // step-3  ----- EndPoint
        String endPoint1 = "/users/c11472";
        
        // Expected Response code - 200 
        // Expected response message
        
        
       
        

		
	int code = RestAssured
		        .given()
		        .header("Authorization", "Bearer " + token)
		        .get(endPoint1).statusCode(); // 200
	
	System.out.println("The status code is : " + " " + code);
		
		
		


	}

}
