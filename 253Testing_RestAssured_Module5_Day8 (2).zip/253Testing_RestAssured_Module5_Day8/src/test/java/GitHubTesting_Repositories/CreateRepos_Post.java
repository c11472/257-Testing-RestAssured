package GitHubTesting_Repositories;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;


public class CreateRepos_Post {
		    public static void main(String[] args) {

	        RestAssured.baseURI = "https://api.github.com";
	        
	       

	        String token = "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";
	        /*String body = """
	            {
	              "name": "restassured-demo-repo2test59090",
	              "description": "Created using GitHub REST API",
	              "private": false
	            }
	            """;*/
	     //{\"propertyname\":\"value\",
	       // \"property2\":\"value2\"}

	        
			String body = 
					"{\"name\": \"restassured-demo-newrepos100\","
					+ " \"description\": \"Created using GitHub REST API\" ,"
					+ "\"name\": \"false\"}";



	        Response response = (Response) given()
	                .auth().oauth2(token)
	                .when()
	                .header("Accept", "application/vnd.github+json")
	                .body(body)
	                .post("/user/repos").then().statusCode(201);
	                

	        System.out.println("Status Code: " + response.getStatusCode());
	        response.prettyPrint();
	        response.prettyPeek();
	        response.asPrettyString();         
	    }		    
	}



