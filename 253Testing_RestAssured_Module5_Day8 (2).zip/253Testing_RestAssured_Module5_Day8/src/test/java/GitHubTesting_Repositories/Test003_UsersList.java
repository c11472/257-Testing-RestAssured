package GitHubTesting_Repositories;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class Test003_UsersList {
	
	public static void main(String[] args) {
		RestAssured.baseURI = "https://api.github.com";
        String token = "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";

		String ep2 = "/users/c11472/repos";
		
		
		String res = RestAssured
		        .given()
		        .header("Authorization", "Bearer " + token).get(ep2).statusLine();
		
		
		
		
		System.out.println(res);
		
		
		ResponseOptions res2=(ResponseOptions) RestAssured
        .given()
        .header("Authorization", "Bearer " + token).get(ep2).getBody();
		
		
		System.out.println(res.toString());
	
	 		
	}

}
