import io.restassured.RestAssured;

public class Test001_Git {
	public static void main(String[] args) {
		
		RestAssured.baseURI = "https://api.apis.guru/v2";
		String ep1 = "/users/c11472/repos";
		
		
		

	}

}
