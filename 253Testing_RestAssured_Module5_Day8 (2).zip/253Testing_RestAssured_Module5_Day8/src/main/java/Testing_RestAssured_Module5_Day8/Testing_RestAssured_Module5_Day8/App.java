package Testing_RestAssured_Module5_Day8.Testing_RestAssured_Module5_Day8;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
